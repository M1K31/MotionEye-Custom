#ifndef _INCLUDE_WEBU_STREAM_H_
#define _INCLUDE_WEBU_STREAM_H_


int webu_stream_mjpeg(struct webui_ctx *webui);
int webu_stream_static(struct webui_ctx *webui);

#endif
